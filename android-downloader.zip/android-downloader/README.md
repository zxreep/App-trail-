# Android Media Downloader App

This is a simple test/demo Android media downloader app built using Kotlin and Jetpack Compose. It integrates `yt-dlp` for media fetching and `FFmpeg` for audio conversion/merging.

## Features

- Paste video URL
- Fetch basic metadata (title, thumbnail, duration)
- Show available qualities (implied by MP4/MP3 options)
- Download MP4 video or MP3 audio
- Simple download progress tracking
- Basic download history
- Dark modern UI

## Stack

- Kotlin
- Jetpack Compose
- MVVM (Model-View-ViewModel)
- Coroutines
- yt-dlp (via command line execution)
- FFmpeg (via command line execution)
- WorkManager for background downloads
- Room for local database
- Coil for image loading

## Setup Instructions

1.  **Prerequisites:**
    *   Android Studio (Bumblebee or newer recommended)
    *   An Android device or emulator running API level 24 or higher.

2.  **Clone the repository:**
    ```bash
    git clone <repository_url> # Replace with actual repository URL if applicable
    cd android-downloader
    ```

3.  **Open in Android Studio:**
    *   Open Android Studio.
    *   Select `File > Open` and navigate to the `android-downloader` directory.

4.  **Install yt-dlp and FFmpeg:**
    This project assumes `yt-dlp` and `FFmpeg` binaries are available and executable within the app's private file directory. For a real application, you would typically bundle these binaries with your app (e.g., in `src/main/assets`) and extract them to `context.filesDir` on first run. For this demo, you would need to manually place the `yt-dlp` and `ffmpeg` executables (compiled for Android's architecture, e.g., `arm64-v8a`, `armeabi-v7a`, `x86_64`, `x86`) into the app's `filesDir` (e.g., `/data/data/com.example.mediadownloader/files/`).

    **Note:** Integrating `yt-dlp` and `FFmpeg` directly into an Android app requires cross-compiling them for Android or using existing Android-specific builds. This is a complex step and beyond the scope of this basic demo's automated setup. For testing, you might need to manually push the binaries to the device's internal storage that the app can access.

    Example (after building/obtaining Android binaries for yt-dlp and ffmpeg):
    ```bash
    adb push yt-dlp /data/local/tmp/yt-dlp
    adb shell su -c "cp /data/local/tmp/yt-dlp /data/data/com.example.mediadownloader/files/yt-dlp && chmod 755 /data/data/com.example.mediadownloader/files/yt-dlp"
    adb push ffmpeg /data/local/tmp/ffmpeg
    adb shell su -c "cp /data/local/tmp/ffmpeg /data/data/com.example.mediadownloader/files/ffmpeg && chmod 755 /data/data/com.example.mediadownloader/files/ffmpeg"
    ```

5.  **Build and Run:**
    *   Sync the Gradle project (File > Sync Project with Gradle Files).
    *   Select your target device/emulator.
    *   Click the `Run` button (green triangle) in Android Studio.

## Required Permissions

The `AndroidManifest.xml` includes the following permissions:

-   `android.permission.INTERNET`: For network access to fetch metadata and download media.
-   `android.permission.WRITE_EXTERNAL_STORAGE`: For saving downloaded media files. (Note: Scoped Storage is ignored for simplicity in this demo, but should be handled properly in a production app).
-   `android.permission.READ_EXTERNAL_STORAGE`: For reading downloaded media files.

## Code Structure

-   `MainActivity.kt`: The main entry point of the application.
-   `ui/`: Contains all Jetpack Compose UI components and screens.
    -   `MainScreen.kt`: The main UI for URL input, metadata display, and download history.
    -   `theme/`: Defines the app's dark theme, colors, and typography.
-   `data/`: Contains data models, Room database, DAO, and repository.
    -   `DownloadItem.kt`: Data class for a downloaded item.
    -   `DownloadDao.kt`: Room Data Access Object for `DownloadItem`.
    -   `AppDatabase.kt`: Room database definition.
    -   `DownloadRepository.kt`: Repository for handling data operations.
-   `viewmodel/`: Contains the `DownloadViewModel` for UI logic and state management.
-   `worker/`: Contains `DownloadWorker` for handling background downloads using WorkManager.
-   `util/`: Utility classes.
    -   `CommandExecutor.kt`: Helper for executing shell commands (for yt-dlp and FFmpeg).
    -   `MetadataFetcher.kt`: Utility to fetch video metadata using yt-dlp.

## Future Improvements (Beyond Demo Scope)

-   Proper `yt-dlp` and `FFmpeg` binary bundling and extraction.
-   More robust error handling and user feedback.
-   Detailed download progress updates in UI.
-   Option to choose download quality/format.
-   Notification for download status.
-   File opening functionality.
-   Deletion of downloaded files.
-   More sophisticated UI/UX.
-   Unit and integration tests.

