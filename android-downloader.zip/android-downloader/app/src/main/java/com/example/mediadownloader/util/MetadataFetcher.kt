package com.example.mediadownloader.util

import android.content.Context
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

object MetadataFetcher {
    
    fun fetchMetadata(context: Context, url: String): VideoMetadata? {
        return try {
            val ytDlpPath = CommandExecutor.getBinaryPath(context, "yt-dlp")
            val command = arrayOf(ytDlpPath, "-j", url)
            
            val process = ProcessBuilder(*command).start()
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val output = StringBuilder()
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                output.append(line)
            }
            process.waitFor()
            
            val json = JSONObject(output.toString())
            VideoMetadata(
                title = json.optString("title", "Unknown Title"),
                thumbnailUrl = json.optString("thumbnail", ""),
                duration = formatDuration(json.optLong("duration", 0)),
                url = url
            )
        } catch (e: Exception) {
            null
        }
    }

    private fun formatDuration(seconds: Long): String {
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        return if (h > 0) {
            String.format("%d:%02d:%02d", h, m, s)
        } else {
            String.format("%d:%02d", m, s)
        }
    }
}

data class VideoMetadata(
    val title: String,
    val thumbnailUrl: String,
    val duration: String,
    val url: String
)
