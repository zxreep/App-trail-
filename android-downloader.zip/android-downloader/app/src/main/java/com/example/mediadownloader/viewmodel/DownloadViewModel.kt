package com.example.mediadownloader.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.*
import com.example.mediadownloader.data.AppDatabase
import com.example.mediadownloader.data.DownloadItem
import com.example.mediadownloader.data.DownloadRepository
import com.example.mediadownloader.data.DownloadStatus
import com.example.mediadownloader.util.MetadataFetcher
import com.example.mediadownloader.util.VideoMetadata
import com.example.mediadownloader.worker.DownloadWorker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class DownloadViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: DownloadRepository
    val downloads: StateFlow<List<DownloadItem>>
    
    private val _metadata = MutableStateFlow<VideoMetadata?>(null)
    val metadata: StateFlow<VideoMetadata?> = _metadata

    private val _isFetching = MutableStateFlow(false)
    val isFetching: StateFlow<Boolean> = _isFetching

    init {
        val downloadDao = AppDatabase.getDatabase(application).downloadDao()
        repository = DownloadRepository(downloadDao)
        
        // Convert Flow to StateFlow for Compose
        val _downloads = MutableStateFlow<List<DownloadItem>>(emptyList())
        downloads = _downloads
        viewModelScope.launch {
            repository.allDownloads.collect {
                _downloads.value = it
            }
        }
    }

    fun fetchMetadata(url: String) {
        viewModelScope.launch(Dispatchers.IO) {
            _isFetching.value = true
            val info = MetadataFetcher.fetchMetadata(getApplication(), url)
            _metadata.value = info
            _isFetching.value = false
        }
    }

    fun startDownload(info: VideoMetadata, format: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val newItem = DownloadItem(
                title = info.title,
                url = info.url,
                thumbnailUrl = info.thumbnailUrl,
                duration = info.duration,
                filePath = "",
                status = DownloadStatus.PENDING
            )
            val id = repository.insert(newItem)

            val downloadRequest = OneTimeWorkRequestBuilder<DownloadWorker>()
                .setInputData(workDataOf(
                    "download_id" to id.toInt(),
                    "video_url" to info.url,
                    "format" to format
                ))
                .setConstraints(Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build())
                .build()

            WorkManager.getInstance(getApplication()).enqueueUniqueWork(
                "download_$id",
                ExistingWorkPolicy.KEEP,
                downloadRequest
            )
            
            // Clear metadata preview after starting download
            _metadata.value = null
        }
    }
}
