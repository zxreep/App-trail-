package com.example.mediadownloader.data

import kotlinx.coroutines.flow.Flow

class DownloadRepository(private val downloadDao: DownloadDao) {
    val allDownloads: Flow<List<DownloadItem>> = downloadDao.getAllDownloads()

    suspend fun insert(downloadItem: DownloadItem): Long {
        return downloadDao.insertDownload(downloadItem)
    }

    suspend fun update(downloadItem: DownloadItem) {
        downloadDao.updateDownload(downloadItem)
    }

    suspend fun delete(downloadItem: DownloadItem) {
        downloadDao.deleteDownload(downloadItem)
    }

    suspend fun getById(id: Int): DownloadItem? {
        return downloadDao.getDownloadById(id)
    }
}
