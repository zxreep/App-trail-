package com.example.mediadownloader.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "downloads")
data class DownloadItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val url: String,
    val thumbnailUrl: String,
    val duration: String,
    val filePath: String,
    val status: DownloadStatus = DownloadStatus.PENDING,
    val progress: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)

enum class DownloadStatus {
    PENDING, DOWNLOADING, COMPLETED, FAILED
}
