package com.example.mediadownloader.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.example.mediadownloader.data.AppDatabase
import com.example.mediadownloader.data.DownloadRepository
import com.example.mediadownloader.data.DownloadStatus
import com.example.mediadownloader.util.CommandExecutor
import java.io.File

class DownloadWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val downloadId = inputData.getInt("download_id", -1)
        val videoUrl = inputData.getString("video_url") ?: return Result.failure()
        val format = inputData.getString("format") ?: "mp4"

        val database = AppDatabase.getDatabase(applicationContext)
        val repository = DownloadRepository(database.downloadDao())
        val downloadItem = repository.getById(downloadId) ?: return Result.failure()

        try {
            // Update status to DOWNLOADING
            repository.update(downloadItem.copy(status = DownloadStatus.DOWNLOADING))

            val outputDir = File(applicationContext.getExternalFilesDir(null), "Downloads")
            if (!outputDir.exists()) outputDir.mkdirs()
            
            val outputFile = File(outputDir, "${downloadItem.title}.$format")
            
            // This is a simplified command. In a real app, you'd use the full path to yt-dlp binary.
            // For this demo, we assume yt-dlp is available in the app's path or assets.
            val ytDlpPath = CommandExecutor.getBinaryPath(applicationContext, "yt-dlp")
            
            val command = if (format == "mp3") {
                arrayOf(ytDlpPath, "-x", "--audio-format", "mp3", "-o", outputFile.absolutePath, videoUrl)
            } else {
                arrayOf(ytDlpPath, "-f", "bestvideo+bestaudio/best", "--merge-output-format", "mp4", "-o", outputFile.absolutePath, videoUrl)
            }

            val exitCode = CommandExecutor.execute(applicationContext, command) { progressLine ->
                // Parse progress from yt-dlp output line and update notification/DB
                // Example: [download]  10.5% of 100.00MiB at 1.23MiB/s ETA 01:10
                val progress = parseProgress(progressLine)
                if (progress != -1) {
                    setProgressAsync(workDataOf("progress" to progress))
                    // Optionally update DB for UI persistence
                }
            }

            return if (exitCode == 0) {
                repository.update(downloadItem.copy(
                    status = DownloadStatus.COMPLETED,
                    progress = 100,
                    filePath = outputFile.absolutePath
                ))
                Result.success()
            } else {
                repository.update(downloadItem.copy(status = DownloadStatus.FAILED))
                Result.failure()
            }

        } catch (e: Exception) {
            repository.update(downloadItem.copy(status = DownloadStatus.FAILED))
            return Result.failure()
        }
    }

    private fun parseProgress(line: String): Int {
        return try {
            if (line.contains("%")) {
                val part = line.split(" ").firstOrNull { it.contains("%") }
                part?.replace("%", "")?.toDouble()?.toInt() ?: -1
            } else -1
        } catch (e: Exception) {
            -1
        }
    }
}
