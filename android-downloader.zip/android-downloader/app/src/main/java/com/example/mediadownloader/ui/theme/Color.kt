package com.example.mediadownloader.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Custom colors for dark theme
val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val DarkPrimary = Color(0xFFBB86FC)
val DarkSecondary = Color(0xFF03DAC6)
val DarkText = Color(0xFFFFFFFF)
val DarkTextSecondary = Color(0xFFCCCCCC)

// Custom colors for light theme (though we're focusing on dark, good to have placeholders)
val LightBackground = Color(0xFFFFFFFF)
val LightSurface = Color(0xFFF5F5F5)
val LightPrimary = Color(0xFF6200EE)
val LightSecondary = Color(0xFF03DAC6)
val LightText = Color(0xFF000000)
val LightTextSecondary = Color(0xFF333333)
