package com.example.mediadownloader.util

import android.content.Context
import android.util.Log
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

object CommandExecutor {
    private const val TAG = "CommandExecutor"

    fun execute(context: Context, command: Array<String>, onProgress: (String) -> Unit): Int {
        return try {
            val processBuilder = ProcessBuilder(*command)
            processBuilder.directory(context.filesDir)
            processBuilder.redirectErrorStream(true)
            
            val process = processBuilder.start()
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                line?.let { 
                    Log.d(TAG, it)
                    onProgress(it)
                }
            }
            
            process.waitFor()
        } catch (e: Exception) {
            Log.e(TAG, "Error executing command", e)
            -1
        }
    }

    // Helper to get binary path (assuming they are in the app's private files or assets)
    fun getBinaryPath(context: Context, binaryName: String): String {
        val binaryFile = File(context.filesDir, binaryName)
        return binaryFile.absolutePath
    }
}
